#!/usr/bin/python

# conditional statements in python
#Example1
print("Example program 1 \n")
mark = 0
if mark:
    print("IF condition is TRUE.Valuee of mark is :", mark)
else:
    print("Now we are in ELSE condition")
    

    
