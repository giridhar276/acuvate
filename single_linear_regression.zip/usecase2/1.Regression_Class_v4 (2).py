import pandas as pd
import sklearn as sk
import math
import numpy as np
from scipy import stats
import matplotlib as matlab
import statsmodels.api as sm

###############LAB:Correlation Calculation########################

#Dataset: Air Travel Data\Air_travel.csv
#Importing Air passengers data
air = pd.read_csv(".\\Datasets\\AirPassengers\\AirPassengers.csv")
air.shape
air.columns.values
air.head(10)
air.describe()

#Find the correlation between number of passengers and promotional budget.
np.corrcoef(air.Passengers,air.Promotion_Budget)

#Draw a scatter plot between number of passengers and promotional budget
matlab.pyplot.scatter(air.Passengers, air.Promotion_Budget)

#Find the correlation between number of passengers and Service_Quality_Score
np.corrcoef(air.Passengers,air.Service_Quality_Score)


##############################################Regression######################################

#Correlation between promotion and passengers count
np.corrcoef(air.Passengers,air.Promotion_Budget)

#Draw a scatter plot between   Promotion_Budget and Passengers. Is there any any pattern between Promotion_Budget and Passengers?
matlab.pyplot.scatter(air.Promotion_Budget,air.Passengers)

#Build a linear regression model and estimate the expected passengers for a Promotion_Budget is 650,000
##Regression Model  promotion and passengers count


X = sm.add_constant(air['Promotion_Budget'])
Y = air['Passengers']


from sklearn.model_selection import train_test_split
train_X,test_X,train_y,test_y = train_test_split(X,Y,train_size=0.8,random_state =100)

#creating your model
model = sm.OLS(train_y,train_X).fit()

model.summary()

### prediction
pred_y = model.predict([1,75000])
pred_y









