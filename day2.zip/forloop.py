## for with range function
for val in range(1,10):
    print(val)

for val in range(10,0,-1):
    print(val)

## for with string
name = "python"
for char in name:
    print(char)
    
## for with list

alist = [10,20,30,40,50,60]
for val in alist:
    print(val)
    
for val in alist[2:]:
    print(val)
    

atup = (10,20,30,60)
for val in atup:
    print(val)
    
## only keys
book = {"chap1":10 , "chap2":20 ,"chap3":30}
for key in book.keys():
    print(key)

## only keys
book = {"chap1":10 , "chap2":20 ,"chap3":30}
for value in book.values():
    print(value)
    
book = {"chap1":10 , "chap2":20 ,"chap3":30}
for key,value in book.items():
    print(key,value)
    
    

