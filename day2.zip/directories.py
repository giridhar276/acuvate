
#1
import os
os.mkdir("demo")



#2   creating directories
for val in range(1,100):
    
    dirname = "dir" +  str(val)
    os.mkdir(dirname)
    
    
    
    
    
#3    removing directories
for val in range(36,100):
    dirname = "dir" +  str(val)
    os.rmdir(dirname)    