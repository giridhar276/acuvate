##### 1st approach
try:
    cityset = set()
    fobj = open("realestate.csv")
    for line in fobj:
        # remove white spaces at the beginning and end of the string
        line = line.strip()
        output = line.split(",")
        city = output[1]  # city
        cityset.add(city)
    
    for element in cityset:
        print(element)
    fobj.close()

    print("Total available cities :" ,len(cityset))
except FileNotFoundError as err:
    print("File not found..")
    print(err)
    
### 2nd approach
try:
    citylist  = list()
    fobj = open("realestate.csv")
    for line in fobj:
        # remove white spaces at the beginning and end of the string
        line = line.strip()
        output = line.split(",")
        city = output[1]  # city
        if city not in citylist:
            citylist.append(city)
    for element in citylist:
        print(element)
    fobj.close()
except FileNotFoundError as err:
    print("File not found..")
    print(err)
    
    
    
try:
    citydict  = dict()
    fobj = open("realestate.csv")
    for line in fobj:
        # remove white spaces at the beginning and end of the string
        line = line.strip()
        output = line.split(",")
        city = output[1]  # city
        citydict[city] = 1
    for element in citydict.keys():
        print(element)
    fobj.close()
except FileNotFoundError as err:
    print("File not found..")
    print(err)    
    
    