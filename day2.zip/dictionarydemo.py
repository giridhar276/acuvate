


book  = {"chap1":10 ,"chap2":20 ,"chap3":30 }


book.
print(book)

print(book["chap1"])  # 10
print(book["chap2"])



data = { "chap1":[10,"UK","Rita"] ,"chap2":[20,"Sheetal","UK"],"chap3":[30,"AUS","Ram"] }

print(data)
print(data["chap1"])