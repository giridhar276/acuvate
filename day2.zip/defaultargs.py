


# default arguments
def add(a = 0,b = 0,c = 0):
    print(a,b,c)


add()
add(10)
add(10,20)
add(10,20,30)