


print(10,20)

print(list(range(1,10,2)))
print(list(range(2,10,2)))

alist = [10,20,3]
print(type(alist))

print(max(alist))

print(min(alist))

print(sum(alist))


name = input("Enter any name :")
print("You entered :", name)