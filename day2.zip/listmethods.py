


alist = [10,20,30,40,1,3]

print(type(alist))

alist.append(60)    # adding one object
print("After appending :", alist)

alist.extend([90,23,94])   # adding iterable(list or tuple) ## adding multiple values
print("After extending:", alist)


print("10 is repeated for ", alist.count(10))

print("30 index is :", alist.index(30))


# list.index(where to index, what to insert)
#list. index(index, value)
alist.insert(3,1000)
print("After inserting :", alist)

alist.pop(0)     # index should be passed
print("After pop operation:", alist)

alist.remove(30)   # pass the value directly without indexing
print("After removing:",alist)

alist.reverse()
print("After reversing :", alist)

alist.sort()
print("After sorting :", alist)

