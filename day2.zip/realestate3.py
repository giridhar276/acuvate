





try:
    fobj = open("realestate.csv")
    for line in fobj:
        # remove white spaces at the beginning and end of the string
        line = line.strip()
        output = line.split(",")
        print("Street :", output[0])
        print("City   :", output[1])
        print("-----------")
    fobj.close()
except FileNotFoundError as err:
    print("File not found..")
    print(err)
    
    