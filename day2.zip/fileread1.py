
## reading the file line by line
# fobj acts as file cursor or file pointer 
fobj = open("languages.txt","r")

for line in fobj:
    # remove whitespaces
    line = line.strip()
    print(line)
fobj.close()



# reading the file at a atime
fobj = open("languages.txt","r")
print(fobj.readlines())
fobj.close()


# using read()   ( not suggested)  ( just like ctrl+A    ctrl + c)
fobj = open("languages.txt","r")
print(fobj.read())
fobj.close()