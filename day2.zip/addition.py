


val1 = int(input("Enter first value:"))

val2 = int(input("Enter second value:"))

total = val1 + val2

print(total)


val1 = input("Enter first value:")

val2 = input("Enter second value:")

total = int(val1) + int(val2)

print(total)