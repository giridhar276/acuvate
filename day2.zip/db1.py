


import pymysql


db = pymysql.connect(host = "localhost",port=3306,user='root',password='india@123',database='acuvate')
print(db)
if db:
    print("Connection successful")
else:
    print('connection failed')
