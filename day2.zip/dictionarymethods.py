


book  = {"chap1":10 ,"chap2":20 ,"chap3":30 }
print(type(book))


print(book.keys())

print(book.values())

print(book.items())


