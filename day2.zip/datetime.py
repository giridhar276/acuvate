


import datetime
print(datetime.datetime.now())






import psutil
print(psutil.cpu_percent())
print()
print(psutil.disk_usage("C:\\"))
print()
print(psutil.disk_partitions())
print()
