
def add(first,second):
    print(first,second)

add(10,20,30)




# fixed arguments
def add(first,second,third):
    print(first,second,third)

add(10,20)