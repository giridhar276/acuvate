try:
    filename = input("Enter any file :")
    fobj = open(filename,"r")
    
    for line in fobj:
        # remove whitespaces
        line = line.strip()
        output = line.split(",")
        print(output[0])
    fobj.close()
    
    #total =1  +"hello"
except FileNotFoundError  as error:
    print("File not found")
    print("System generated error :", error)
except ValueError as err:
    print("Invalid operation")
    print("System generated error :", err)
except (TypeError,IndexError,FileExistsError) as err:
    print("Invalid input")
    print("System generated error :", err)
except Exception as err:
    print(err)
finally:
    print("this will be executed all the times")
    
    
    







