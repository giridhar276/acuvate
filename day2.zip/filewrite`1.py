

## write operation
## file will be created in local( current directory)
fobj  = open("customers.txt","w")

fobj.write("unix programming\n")

fobj.close()



## 
fobj  = open("D:\\new\\a\\b\\c\\new\\customers.txt","w")

fobj.write("unix programming\n")

fobj.close()