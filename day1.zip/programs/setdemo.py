



aset = {10,20,30,30,30,45,43,64,32546,4343,10,10,434}
print(aset)


alist = [10,20,30,30,30,10,40,50]

alist = list(set(alist))
print(alist)