


atup = (30,40,50,60)

print(atup.count(40))
