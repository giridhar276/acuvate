
aval = 10
bval = 454.4

print(aval)

print(aval,bval)

print("The values are ",aval,bval)


