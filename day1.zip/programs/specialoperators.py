


name = "python programming prog"

#1st
if name.find("prog") != -1 :
    print("exists")

#2nd
if name.count("prog") > 0:
    print("exists")
    
#3rd
if "prog" in name :
    print("exists")
 
    
alist = [10,20,30,40]

#
if alist.count(10) > 0 :
    print("exists")
    
if 10 in alist:
    print("exists")
    
    
book = {"chap1":10 ,"chap2":20}

if "chap1" in book:
    print("key exists")



