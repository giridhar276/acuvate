

## write operation

fobj  = open("customers.txt","w")

fobj.write("unix programming\n")

fobj.close()




fobj  = open("D:\\new\\customers.txt","w")

fobj.write("unix programming\n")

fobj.close()