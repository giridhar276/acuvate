


atup = (10,20,30,454)
btup = ("hadoop","java")
ctup = (23.4,43,43,"scala")


print(atup)
print("Elements are",btup)

#atup[0] = "python"
#print("After replacing", atup)


alist =  list(atup)
alist[0] = "scala"
print(tuple(alist))



