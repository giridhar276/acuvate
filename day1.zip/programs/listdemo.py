

alist = [10,20,30,40]
blist = ["unix","hadoop","java"]
clist = ["python",243,56.4,"java"]




print(alist)
print(alist,blist,clist)
print("Values are",alist)

print(alist[0])   # 10
print(alist[0:3])

print(alist[::-1])



alist[0] = 1000

print("After replacing",alist)