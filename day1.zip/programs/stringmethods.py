name = "python programming"

print(name.capitalize())

print(name.upper())

print(name.lower())

print(name.split(" "))

print(name.count("p"))

print(name.count("prog"))

print(name.find("prog"))      # starting index number
print(name.find("adadadad"))  # -1  # not existing


print(name.replace("python","scala"))



if name.isupper():
    print("String is defined in upper")
else:
    print("String is defined in lower")
   
    
name = "python programming"
if name.isalpha():
    print("String has only alphabets")
else:
    print("String has special characters")
    
    
    
if name.find("prog") != -1 :
    print("String has 'prog'")
else:
    print("not existing")

    
line = "python\njava\nunix"
print(line.splitlines())


