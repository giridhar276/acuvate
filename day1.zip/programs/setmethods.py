


aset = {10,20,30,30,20,20,20,10}
print(aset)


bset = {30,40,50,50,30,40,40,40}
print(bset)

print(aset.union(bset))

print(aset.intersection(bset))

print(aset.issubset(bset))

print(aset.difference(bset))

print(bset.difference(aset))