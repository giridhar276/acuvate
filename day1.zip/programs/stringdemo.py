
## string slicing

name = "python programming"

print("I am learning",name)

print(name)

print(name[0])    # p
print(name[1])    # y
print(name[0:5])
print(name[4:8])
print(name[:])
print(name[::])
print(name[0::])
print(name[0:16:2])
print(name[1:16:2])
print(name[::4])
print(name[::2])
print(name[-1])

print(name[::-1]) #gnimmargorp nohtyp